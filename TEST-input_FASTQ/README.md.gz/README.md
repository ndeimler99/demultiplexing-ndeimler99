Please upload your 4 input test FASTQ files to this directory. Make sure they are *properly formatted* FASTQ files.
